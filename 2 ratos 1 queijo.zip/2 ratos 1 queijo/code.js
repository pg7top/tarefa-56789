var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["6bb35ab4-3fc3-4ffa-9e88-f3a072762043","6dee4d57-fbc1-4b41-b20e-f7456029056c","cc240f6c-fe0e-4e85-9da0-1e04db4b5ca9","852674cc-0d41-4eb4-93ec-c1fcac5170c7","5120b10f-9fd2-4b95-8a91-83e8004f4f4b","ecd11c56-59b1-4ddc-920f-8946a900ec7c","3c759d32-20ed-433d-9211-c5483e32faa7"],"propsByKey":{"6bb35ab4-3fc3-4ffa-9e88-f3a072762043":{"name":"rato1","sourceUrl":"assets/api/v1/animation-library/gamelab/JiNH1fnncYd5VrE5Js_QJMmE4Vm1Lt2p/category_animals/mouse.png","frameSize":{"x":61,"y":37},"frameCount":2,"looping":true,"frameDelay":2,"version":"JiNH1fnncYd5VrE5Js_QJMmE4Vm1Lt2p","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":122,"y":37},"rootRelativePath":"assets/api/v1/animation-library/gamelab/JiNH1fnncYd5VrE5Js_QJMmE4Vm1Lt2p/category_animals/mouse.png"},"6dee4d57-fbc1-4b41-b20e-f7456029056c":{"name":"rato2","sourceUrl":"assets/api/v1/animation-library/gamelab/JiNH1fnncYd5VrE5Js_QJMmE4Vm1Lt2p/category_animals/mouse.png","frameSize":{"x":61,"y":37},"frameCount":2,"looping":true,"frameDelay":2,"version":"JiNH1fnncYd5VrE5Js_QJMmE4Vm1Lt2p","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":122,"y":37},"rootRelativePath":"assets/api/v1/animation-library/gamelab/JiNH1fnncYd5VrE5Js_QJMmE4Vm1Lt2p/category_animals/mouse.png"},"cc240f6c-fe0e-4e85-9da0-1e04db4b5ca9":{"name":"queijo","sourceUrl":"assets/api/v1/animation-library/gamelab/BnRZRFpznzKZ.5IPc97zl99rHJyU2geK/category_food/cheese.png","frameSize":{"x":379,"y":360},"frameCount":1,"looping":true,"frameDelay":2,"version":"BnRZRFpznzKZ.5IPc97zl99rHJyU2geK","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":379,"y":360},"rootRelativePath":"assets/api/v1/animation-library/gamelab/BnRZRFpznzKZ.5IPc97zl99rHJyU2geK/category_food/cheese.png"},"852674cc-0d41-4eb4-93ec-c1fcac5170c7":{"name":"panela1","sourceUrl":null,"frameSize":{"x":146,"y":104},"frameCount":1,"looping":true,"frameDelay":12,"version":"keeJxWOaIz.Qf_SKCrDS4BbUj.Ph0s2H","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":146,"y":104},"rootRelativePath":"assets/852674cc-0d41-4eb4-93ec-c1fcac5170c7.png"},"5120b10f-9fd2-4b95-8a91-83e8004f4f4b":{"name":"mixer","sourceUrl":"assets/api/v1/animation-library/gamelab/RfEppCGS2ac.Ye75tp1Jm.ivl3HqGcOo/category_household_objects/mixer.png","frameSize":{"x":132,"y":109},"frameCount":1,"looping":true,"frameDelay":4,"version":"RfEppCGS2ac.Ye75tp1Jm.ivl3HqGcOo","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":132,"y":109},"rootRelativePath":"assets/api/v1/animation-library/gamelab/RfEppCGS2ac.Ye75tp1Jm.ivl3HqGcOo/category_household_objects/mixer.png"},"ecd11c56-59b1-4ddc-920f-8946a900ec7c":{"name":"mixer_copy_1","sourceUrl":"assets/api/v1/animation-library/gamelab/RfEppCGS2ac.Ye75tp1Jm.ivl3HqGcOo/category_household_objects/mixer.png","frameSize":{"x":132,"y":109},"frameCount":1,"looping":true,"frameDelay":4,"version":"RfEppCGS2ac.Ye75tp1Jm.ivl3HqGcOo","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":132,"y":109},"rootRelativePath":"assets/api/v1/animation-library/gamelab/RfEppCGS2ac.Ye75tp1Jm.ivl3HqGcOo/category_household_objects/mixer.png"},"3c759d32-20ed-433d-9211-c5483e32faa7":{"name":"mesinha","sourceUrl":"assets/api/v1/animation-library/gamelab/F98HO0iBNMl1uw1QY2tpaXyj_lRKOBzo/category_board_games_and_cards/table.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":"F98HO0iBNMl1uw1QY2tpaXyj_lRKOBzo","categories":["board_games_and_cards"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/F98HO0iBNMl1uw1QY2tpaXyj_lRKOBzo/category_board_games_and_cards/table.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----



var mesa = createSprite(200,30,350,70);
mesa.shapeColor="white";

var tapete = createSprite(200, 200,300,150);
tapete.shapeColor="white";
tapete.setAnimation("mesinha");
tapete.scale=1;


var queijo = createSprite(320, 25,15,25);
queijo.shapeColor="yellow";
queijo.setAnimation("queijo");
queijo.scale=0.09;

var pia = createSprite(230, 30,10,40);
pia.setAnimation("mixer");
pia.shapeColor="gray";
pia.scale=0.3;

var detalhes = createSprite(140, 30,80,30);
detalhes.shapeColor="gray";

var gameState = "serve";



var rato2 = createSprite(30, 350,25,35);
rato2.shapeColor="brown";
rato2.setAnimation("rato2");
rato2.scale=0.7;

var rato1 = createSprite(75, 350,25,35);
rato1.setAnimation("rato1");
rato1.shapeColor="brown";
rato1.scale=0.7;























function draw() {
background("gray");
createEdgeSprites();
rato1.bounceOff(edges);
rato2.bounceOff(edges);
if (rato1.isTouching(queijo)) {
  queijo.x=rato1.x; 
  queijo.y=rato1.y;
  
}
if (rato2.isTouching(queijo)) {
  queijo.x=rato2.x; 
  queijo.y=rato2.y;
  
}
if(gameState == "serve"){
  //exibindo texto de boas-vindas
    textSize(19);
    fill("red");
    text(" bem vindos! precionem enter para começarem",0,100);  
   //Movendo a bola ao pressionar a tecla enter
    if(keyDown("enter")){
       gameState = "play";
             
     
   }
    
  }

if (gameState == "play") {
   
  if (keyDown("LEFT")) {
            rato1.x=rato1.x - 6;  
                      }
                if (keyDown("RIGHT")) {
                   rato1.x=rato1.x + 6;  
                      }
                  if (keyDown("UP")) {
                    rato1.y=rato1.y - 6;  
                      }
                    if (keyDown("DOWN")) {
                     rato1.y=rato1.y + 6;  
                      }
                     if (keyDown("A")) {
                      rato2.x=rato2.x - 6;  
                      }
                    if (keyDown("D")) {
                      rato2.x=rato2.x + 6;  
                      }
                     if (keyDown("W")) {
                      rato2.y=rato2.y - 6;  
                      }
                     if (keyDown("S")) {
                      rato2.y=rato2.y + 6;  
                      }
 
   if (rato1.isTouching(queijo)) {
  queijo.x=rato1.x; 
  queijo.y=rato1.y;
  
}
if (rato2.isTouching(queijo)) {
  queijo.x=rato2.x; 
  queijo.y=rato2.y;
  
} 
         
   }












drawSprites();
    
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
